const sha1 = require('node-sha1');
const mcached = require('memchync');
const process = require('process');
const zookeeper = require("node-zookeeper-client");
const client = zookeeper.createClient('localhost:2181');
const fs = require("fs-promise");
let arrAllNodes = [];
let arrLiveNodes = [];
let bGotAllNodesList = false;
let bGotLiveNodesList = false;
let objServerHashes = {};
const sleep = require('sleepjs')

const objAllServers = {
    "memcached1": "127.0.0.1:11211"
}

let objMemcachedConfig = {
    retries: 1,
    retry: 50,
    timeout:1000
};

const maxNodes = Object.keys(objAllServers).length;

function getHashes() {
    for(let strServername in objAllServers) {
       objServerHashes[strServername] = sha1(objAllServers[strServername]); 
    }
}

function getMemcachedNode(key) {
    let nodeIndex = sha1(key) % arrLiveNodes.length;
    let strServerName = arrLiveNodes[nodeIndex];
    return strServerName;
}

function eventWatcher(event) {
    client.getChildren('/servers/live_nodes', eventWatcher,  function (error, children, stat) {
        if (error) {
            console.log(error);
            return;
        }
        arrLiveNodes = children;
        console.log("Live ", arrLiveNodes);
    });
}

function getLiveNodes() {
    client.getChildren('/servers/live_nodes', eventWatcher,  function (error, children, stat) {
        if (error) {
            console.log("Please register the Memcached servers before running the client");
            process.exit(0);
            return;
        }
        arrLiveNodes = children;
        bGotLiveNodesList = true;
        console.log("Live ", arrLiveNodes);
    });
}

function getAllNodes() {
    client.getChildren('/servers/all_nodes', function (error, children, stat) {
        if (error) {
            console.log("Please register the Memcached servers before running the client");
            process.exit(0);
            return;
        }
        arrAllNodes = children;
        console.log("All nodes", arrAllNodes);
        let arrConfiguredNodes = Object.keys(objAllServers);
        if(arrAllNodes.length !== arrConfiguredNodes.length) {
            console.log("Server ip and port object misconfigured. There are " + arrAllNodes.length + " in the config, but in Zookeeper there are " + arrConfiguredNodes.length + " nodes");
            process.exit(0);
        }
        bGotAllNodesList = true;
    });
}

async function put(key, value) {
    try {
        let memcachedNodeIP = objAllServers[getMemcachedNode(key)];
        mcached.init(memcachedNodeIP, objMemcachedConfig);
        await mcached.set(key, value, 3600);
    } catch(error) {
        console.error(error);
    }
}

async function get(key) {
    let value;

    for(let i = 0; i < arrLiveNodes.length; i++) {
        try {
            console.log(objAllServers[arrLiveNodes[i]]);
            mcached.init(objAllServers[arrLiveNodes[i]], objMemcachedConfig);
            value = await mcached.get(key);
            if(typeof value !== 'undefined') {
                break;
            }
        } catch(error) {
            console.error(error);
        }
    }

    return value;
}

async function startDHT() {
    let arrLines = fs.readFileSync('input', 'utf8').split('\n');
    for(let line of arrLines) {
        if(line.length) {
            let arrCommand = line.replace(/\s+/g,' ').split(' ');
            //assuming input file is always according to specs, validation is skipped.
            let strCommand = arrCommand[0];
            if(["GET", "PUT", "SLEEP"].includes(strCommand)) {
                if(strCommand === "GET") {
                    let key = arrCommand[1];
                    let value = await get(key);
                    console.log("Read value: ", value);
                } else if (strCommand === "PUT") {
                    let key = arrCommand[1];
                    let value = arrCommand[2];
                    await put(key, value);
                } else if (strCommand === "SLEEP") {
                    let time = arrCommand[1];
                    await sleep(time);
                }
            }
        }
    }
}

(async () => {

    client.connect();
    client.once('connected', async () => {
        getAllNodes();
        getLiveNodes();
        getHashes();    
    
        let flagCheck = setInterval(() => {
            if(bGotAllNodesList && bGotLiveNodesList) {
                clearInterval(flagCheck);
                startDHT();
            }
        }, 50);
    });
})();
