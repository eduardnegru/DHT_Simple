#!/bin/bash

service memcached start
/usr/bin/node watchdog.js m1

