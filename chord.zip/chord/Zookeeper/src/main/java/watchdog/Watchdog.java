package watchdog;

import javax.swing.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashMap;

public class Watchdog {

    public static HashMap<String, Boolean> serverStatus = new HashMap<>();

    public static boolean pingHost(String ipAddress, int port, int timeoutMillis) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ipAddress, port), timeoutMillis);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        while (true) {
            try {
                for (Server server : Config.registeredServers) {
                    boolean hostReachable = pingHost(server.ipAddress, server.port, Config.PROBE_TIMEOUT_MILLIS);
                    serverStatus.put(server.toString(), hostReachable);
                }
                Thread.sleep(5000);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
}
