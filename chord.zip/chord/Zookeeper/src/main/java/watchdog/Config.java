package watchdog;

public class Config {

    public static int PROBE_TIMEOUT_MILLIS = 2000;

    public static Server[] registeredServers = {
        new Server("127.0.0.1", 11211)
    };

}
