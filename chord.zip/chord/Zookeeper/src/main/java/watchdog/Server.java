package watchdog;

public class Server {
    public String ipAddress;
    public int port;

    public Server(String ipAddress, int port) {
        this.ipAddress = ipAddress;
        this.port = port;
    }

    @Override
    public String toString() {
        return ipAddress + ':' + port;
    }
}
